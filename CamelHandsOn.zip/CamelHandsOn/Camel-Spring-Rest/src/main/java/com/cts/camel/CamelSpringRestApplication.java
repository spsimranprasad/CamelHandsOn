package com.cts.camel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelSpringRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelSpringRestApplication.class, args);
	}

}
